MooLog PWA

FILES
- index.html — the MooLog app
- manifest.webmanifest — tells Android how to install MooLog
- sw.js — offline support
- icon-192.png / icon-512.png — app icons

IMPORTANT
These files must stay together and be hosted on an HTTPS website for full PWA installation.
Do not open index.html directly from Downloads and expect the installable PWA features to work.

Before moving from an older local HTML copy, save a MooLog backup from the old app.
Browser localStorage belongs to the page/site it was created on, so a newly hosted copy will not automatically inherit data stored by an older file URL.
